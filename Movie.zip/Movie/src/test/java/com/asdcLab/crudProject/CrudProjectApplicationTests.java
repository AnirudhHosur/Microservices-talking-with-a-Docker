package com.asdcLab.crudProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
