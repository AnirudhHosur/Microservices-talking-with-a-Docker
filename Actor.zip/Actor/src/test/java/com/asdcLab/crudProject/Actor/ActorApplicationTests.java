package com.asdcLab.crudProject.Actor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActorApplicationTests {

	@Test
	void contextLoads() {
	}

}
