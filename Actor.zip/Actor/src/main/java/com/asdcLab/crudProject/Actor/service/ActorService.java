package com.asdcLab.crudProject.Actor.service;

import com.asdcLab.crudProject.Actor.model.Actor;

import java.util.List;

public interface ActorService {
    List<Actor> getActors();
    Object getMovies();
}
